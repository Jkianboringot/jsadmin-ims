[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[ ] 3. Verify the project is working using the feedback tool
[ ] 4. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool